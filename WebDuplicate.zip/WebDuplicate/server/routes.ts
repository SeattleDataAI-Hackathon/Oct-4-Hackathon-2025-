import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import session from "express-session";
import connectPg from "connect-pg-simple";
import bcrypt from "bcrypt";
import { 
  registrationSchema, 
  loginSchema,
  createCaseSchema,
  createCommentSchema,
  createVoteSchema,
  updateUserSchema,
} from "@shared/schema";

declare module 'express-session' {
  interface SessionData {
    userId: string;
  }
}

// Session middleware
function setupSession(app: Express) {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });

  app.use(
    session({
      secret: process.env.SESSION_SECRET || 'p2pconsult-secret-key',
      store: sessionStore,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        maxAge: sessionTtl,
      },
    })
  );
}

// Auth middleware
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.session.userId) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

const isAdmin = async (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const user = await storage.getUser(req.session.userId);
  if (user?.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Forbidden - Admin access required" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(express.json());
  setupSession(app);

  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validationResult = registrationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.issues 
        });
      }

      const { username, password, email, fullName, institute } = validationResult.data;

      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        username,
        password,
        email,
        fullName,
        institute,
        hashedPassword,
      });

      req.session.userId = user.id;
      res.json({ message: "Registration successful", user: { id: user.id, username: user.username } });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const validationResult = loginSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.issues 
        });
      }

      const { username, password } = validationResult.data;
      const user = await storage.getUserByUsername(username);

      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      res.json({ 
        message: "Login successful", 
        user: { 
          id: user.id, 
          username: user.username, 
          fullName: user.fullName,
          isAdmin: user.isAdmin 
        } 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to login" });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Case routes
  app.get('/api/cases', isAuthenticated, async (req, res) => {
    try {
      const allCases = await storage.getAllCases();
      const casesWithDetails = await Promise.all(
        allCases.map(async (caseItem) => {
          const author = await storage.getUser(caseItem.authorId);
          const pollOptions = await storage.getPollOptionsByCase(caseItem.id);
          const voteCounts = await storage.getVoteCountsForCase(caseItem.id);
          const mediaFiles = await storage.getMediaFilesByCase(caseItem.id);
          
          return {
            ...caseItem,
            author: author ? { id: author.id, username: author.username, fullName: author.fullName } : null,
            pollOptions,
            voteCounts,
            mediaFiles,
          };
        })
      );
      res.json(casesWithDetails);
    } catch (error) {
      console.error("Error fetching cases:", error);
      res.status(500).json({ message: "Failed to fetch cases" });
    }
  });

  app.get('/api/cases/:id', isAuthenticated, async (req, res) => {
    try {
      const caseItem = await storage.getCase(req.params.id);
      if (!caseItem) {
        return res.status(404).json({ message: "Case not found" });
      }

      const author = await storage.getUser(caseItem.authorId);
      const pollOptions = await storage.getPollOptionsByCase(caseItem.id);
      const voteCounts = await storage.getVoteCountsForCase(caseItem.id);
      const mediaFiles = await storage.getMediaFilesByCase(caseItem.id);
      const comments = await storage.getCommentsByCase(caseItem.id);

      const commentsWithDetails = await Promise.all(
        comments.map(async (comment) => {
          const commentAuthor = await storage.getUser(comment.authorId);
          const likeCount = await storage.getCommentLikeCount(comment.id);
          const userLiked = await storage.hasUserLikedComment(comment.id, (req as any).session.userId);
          
          return {
            ...comment,
            author: commentAuthor ? { id: commentAuthor.id, username: commentAuthor.username, fullName: commentAuthor.fullName } : null,
            likeCount,
            userLiked,
          };
        })
      );

      const userVote = await storage.getUserVoteForCase((req as any).session.userId, caseItem.id);

      res.json({
        ...caseItem,
        author: author ? { id: author.id, username: author.username, fullName: author.fullName } : null,
        pollOptions,
        voteCounts,
        mediaFiles,
        comments: commentsWithDetails,
        userVote,
      });
    } catch (error) {
      console.error("Error fetching case:", error);
      res.status(500).json({ message: "Failed to fetch case" });
    }
  });

  app.post('/api/cases', isAuthenticated, async (req: any, res) => {
    try {
      const validationResult = createCaseSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.issues 
        });
      }

      const { title, question, description, customPollOptions } = validationResult.data;

      const caseItem = await storage.createCase({
        authorId: req.session.userId,
        title,
        question,
        description,
      });

      // Create custom poll options
      for (let i = 0; i < customPollOptions.length; i++) {
        await storage.createPollOption({
          caseId: caseItem.id,
          optionText: customPollOptions[i],
          orderIndex: i,
          isStandardOption: false,
        });
      }

      // Add the three standard options
      const standardOptions = [
        "None of the answers listed above, however I don't know the answer.",
        "None of the answers listed above. I entered my opinion in the comment section below.",
        "None of the answers listed above, but I agree with the answer entered in the comment below by another user. (Please click 'like' on that particular comment.)",
      ];

      for (let i = 0; i < standardOptions.length; i++) {
        await storage.createPollOption({
          caseId: caseItem.id,
          optionText: standardOptions[i],
          orderIndex: customPollOptions.length + i,
          isStandardOption: true,
        });
      }

      res.json({ message: "Case created successfully", caseId: caseItem.id });
    } catch (error) {
      console.error("Error creating case:", error);
      res.status(500).json({ message: "Failed to create case" });
    }
  });

  app.delete('/api/cases/:id', isAuthenticated, async (req: any, res) => {
    try {
      const caseItem = await storage.getCase(req.params.id);
      if (!caseItem) {
        return res.status(404).json({ message: "Case not found" });
      }

      const user = await storage.getUser(req.session.userId);
      if (caseItem.authorId !== req.session.userId && !user?.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteCase(req.params.id);
      res.json({ message: "Case deleted successfully" });
    } catch (error) {
      console.error("Error deleting case:", error);
      res.status(500).json({ message: "Failed to delete case" });
    }
  });

  // Vote routes
  app.post('/api/cases/:id/vote', isAuthenticated, async (req: any, res) => {
    try {
      const caseId = req.params.id;
      const { pollOptionId } = req.body;

      if (!pollOptionId) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: [{ message: "pollOptionId is required" }]
        });
      }

      // Verify the case exists
      const caseItem = await storage.getCase(caseId);
      if (!caseItem) {
        return res.status(404).json({ message: "Case not found" });
      }

      // Verify the poll option belongs to this case
      const pollOptions = await storage.getPollOptionsByCase(caseId);
      const validOption = pollOptions.find(opt => opt.id === pollOptionId);
      if (!validOption) {
        return res.status(400).json({ message: "Invalid poll option for this case" });
      }

      // Check if user already voted
      const existingVote = await storage.getUserVoteForCase(req.session.userId, caseId);
      if (existingVote) {
        return res.status(400).json({ message: "You have already voted on this case" });
      }

      await storage.createVote({
        pollOptionId,
        userId: req.session.userId,
        caseId,
      });

      res.json({ message: "Vote recorded successfully" });
    } catch (error) {
      console.error("Error creating vote:", error);
      res.status(500).json({ message: "Failed to record vote" });
    }
  });

  // Comment routes
  app.post('/api/cases/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const caseId = req.params.id;
      const content = req.body.content;

      if (!content || typeof content !== 'string' || content.trim() === '') {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: [{ message: "Content is required" }]
        });
      }

      const comment = await storage.createComment({
        caseId,
        authorId: req.session.userId,
        content: content.trim(),
      });

      const author = await storage.getUser(req.session.userId);

      res.json({ 
        ...comment,
        author: author ? { id: author.id, username: author.username, fullName: author.fullName } : null,
        likeCount: 0,
        userLiked: false,
      });
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  app.delete('/api/comments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const comments = await storage.getCommentsByCase(''); // We need the comment itself
      const comment = comments.find(c => c.id === req.params.id);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }

      const user = await storage.getUser(req.session.userId);
      if (comment.authorId !== req.session.userId && !user?.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteComment(req.params.id);
      res.json({ message: "Comment deleted successfully" });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  app.post('/api/comments/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      await storage.toggleCommentLike(req.params.id, req.session.userId);
      const likeCount = await storage.getCommentLikeCount(req.params.id);
      const userLiked = await storage.hasUserLikedComment(req.params.id, req.session.userId);
      
      res.json({ likeCount, userLiked });
    } catch (error) {
      console.error("Error toggling comment like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  // Admin routes
  app.get('/api/admin/users', isAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      const usersWithoutPasswords = allUsers.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch('/api/admin/users/:id', isAdmin, async (req, res) => {
    try {
      const validationResult = updateUserSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.issues 
        });
      }

      const user = await storage.updateUser(req.params.id, validationResult.data);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete('/api/admin/users/:id', isAdmin, async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
