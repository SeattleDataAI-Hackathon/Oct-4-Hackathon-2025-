import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { ArrowLeft, Plus, X } from "lucide-react";

const STANDARD_OPTIONS = [
  "None of the answers listed above, however I don't know the answer.",
  "None of the answers listed above. I entered my opinion in the comment section below.",
  "None of the answers listed above, but I agree with the answer entered in the comment below by another user. (Please click 'like' on that particular comment.)"
];

export default function CreateCasePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [title, setTitle] = useState("");
  const [question, setQuestion] = useState("");
  const [description, setDescription] = useState("");
  const [customOptions, setCustomOptions] = useState<string[]>([""]);

  const createCaseMutation = useMutation({
    mutationFn: async (data: { title: string; question: string; description: string; customPollOptions: string[] }) => {
      return apiRequest("POST", "/api/cases", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
      toast({
        title: "Case Created",
        description: "Your case has been successfully created.",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create case",
        variant: "destructive",
      });
    },
  });

  const handleAddOption = () => {
    setCustomOptions([...customOptions, ""]);
  };

  const handleRemoveOption = (index: number) => {
    setCustomOptions(customOptions.filter((_, i) => i !== index));
  };

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...customOptions];
    newOptions[index] = value;
    setCustomOptions(newOptions);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a case title",
        variant: "destructive",
      });
      return;
    }

    if (!question.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter your question",
        variant: "destructive",
      });
      return;
    }

    if (!description.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a case description",
        variant: "destructive",
      });
      return;
    }

    const validCustomOptions = customOptions.filter(opt => opt.trim() !== "");
    
    if (validCustomOptions.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please add at least one custom poll option",
        variant: "destructive",
      });
      return;
    }

    createCaseMutation.mutate({
      title: title.trim(),
      question: question.trim(),
      description: description.trim(),
      customPollOptions: validCustomOptions,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Create New Case</h1>
              <p className="text-sm text-muted-foreground">Share a patient case with your peers</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Case Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Case Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter a brief title for the case"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  data-testid="input-title"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="question">What is your question? *</Label>
                <Input
                  id="question"
                  placeholder="Enter your question"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  data-testid="input-question"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Case Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the patient case in detail..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={6}
                  data-testid="input-description"
                />
              </div>

              <div className="border-t pt-6">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="font-semibold">Custom Poll Options *</h3>
                    <p className="text-sm text-muted-foreground">
                      Add custom options for your colleagues to vote on
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleAddOption}
                    data-testid="button-add-option"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Option
                  </Button>
                </div>

                <div className="space-y-3">
                  {customOptions.map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder={`Option ${index + 1}`}
                        value={option}
                        onChange={(e) => handleOptionChange(index, e.target.value)}
                        data-testid={`input-option-${index}`}
                      />
                      {customOptions.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveOption(index)}
                          data-testid={`button-remove-option-${index}`}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold mb-3">Standard Options (Auto-added)</h3>
                <div className="space-y-2">
                  {STANDARD_OPTIONS.map((option, index) => (
                    <div
                      key={index}
                      className="p-3 bg-muted rounded-md text-sm"
                      data-testid={`standard-option-${index}`}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation("/")}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createCaseMutation.isPending}
              data-testid="button-create-case"
            >
              {createCaseMutation.isPending ? "Creating..." : "Create Case"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
}
