# P2Pconsult - Healthcare Case Discussion Platform

## Overview

P2Pconsult is a collaborative platform for healthcare professionals to share, discuss, and vote on medical cases. The application enables users to post clinical cases, attach media files, create polls for treatment options, and engage in threaded discussions through comments. It features role-based access control with admin capabilities for user management.

## Recent Changes

**October 2025**
- Added "What is your question?" field to case creation form
- Question field is required and displayed prominently on case detail pages
- Fixed routing issue by refactoring Router component to properly handle route matching

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework and Tooling**
- Built with React 18 and TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot module replacement
- Wouter for lightweight client-side routing without the overhead of React Router
- TanStack Query (React Query) for server state management, caching, and data synchronization

**UI Component System**
- Shadcn/ui component library with Radix UI primitives for accessible, unstyled components
- Tailwind CSS for utility-first styling with custom CSS variables for theming
- "New York" style variant configured for visual consistency
- Comprehensive component set including forms, dialogs, tables, toasts, and navigation elements

**State Management Strategy**
- Server state managed through React Query with infinite stale time to prevent unnecessary refetches
- Form state handled by React Hook Form with Zod schema validation
- Session-based authentication state tracked through React Query's `/api/auth/user` endpoint
- Local UI state managed with React hooks (useState, useEffect)

**Routing and Navigation**
- Public routes (login, register) redirect authenticated users to home
- Protected routes redirect unauthenticated users to login
- Route-based code splitting through dynamic imports
- Auth loading state prevents flash of wrong content
- Router refactored to avoid nested conditional Switch components for proper route matching

### Backend Architecture

**Server Framework**
- Express.js REST API with TypeScript
- Session-based authentication using express-session with PostgreSQL session store
- Bcrypt for password hashing with configurable salt rounds
- Custom middleware for request logging, JSON parsing, and authentication verification

**API Design Pattern**
- RESTful endpoints organized by resource (`/api/auth`, `/api/cases`, `/api/comments`, `/api/votes`)
- Consistent error handling with HTTP status codes
- JSON request/response format
- Session cookies for maintaining authentication state

**Database Layer**
- Drizzle ORM with type-safe query building
- Neon serverless PostgreSQL for database hosting
- WebSocket connection pooling for optimal performance
- Schema-first design with TypeScript inference

**Database Schema**
- `users`: Authentication and profile data with admin role flag
- `sessions`: Server-side session storage with TTL expiration
- `cases`: Medical case posts with title, question, description, and author reference
- `pollOptions`: Multiple choice options for case discussions
- `votes`: User votes on poll options (one vote per user per case)
- `comments`: Threaded discussion on cases
- `commentLikes`: User engagement on comments
- `mediaFiles`: Attached images/files for cases

**Authentication Flow**
- Registration creates user with hashed password and auto-login
- Login validates credentials and establishes session
- Session middleware protects routes requiring authentication
- Admin flag on user model enables privileged operations

**Data Access Layer**
- Storage interface pattern abstracts database operations
- CRUD operations for all entities (users, cases, comments, votes)
- Relational queries using Drizzle's join capabilities
- Soft delete pattern available through schema design

### External Dependencies

**Database**
- Neon Serverless PostgreSQL (`@neondatabase/serverless`)
- Connection pooling with WebSocket support for serverless environments
- Drizzle ORM for schema management and queries
- Database migrations managed through `drizzle-kit`

**Session Management**
- `express-session` for server-side session handling
- `connect-pg-simple` for PostgreSQL session store
- Session TTL set to 1 week with automatic cleanup
- HTTP-only, secure cookies in production

**Authentication**
- `bcrypt` for password hashing and verification
- Password strength enforced through Zod schema validation
- Session-based authentication without JWT tokens

**Development Tools**
- Replit-specific plugins for development banner and cartographer in dev mode
- Runtime error modal for better debugging experience
- TSX for running TypeScript files directly in development
- ESBuild for production bundling

**Environment Variables Required**
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret key for session signing
- `NODE_ENV`: Environment indicator (development/production)
- `REPL_ID`: Optional Replit deployment identifier