import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, ThumbsUp, MessageSquare, User, Calendar, Sparkles } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface CaseDetail {
  id: string;
  authorId: string;
  title: string;
  question: string;
  description: string;
  createdAt: string;
  author: {
    id: string;
    username: string;
    fullName: string;
  } | null;
  pollOptions: Array<{
    id: string;
    optionText: string;
    orderIndex: number;
    isStandardOption: boolean;
    isAiGenerated: boolean;
  }>;
  voteCounts: { pollOptionId: string; count: number }[];
  userVote: { pollOptionId: string } | null;
  comments: Array<{
    id: string;
    userId: string;
    content: string;
    createdAt: string;
    user: {
      id: string;
      username: string;
      fullName: string;
    } | null;
    likeCount: number;
    userLiked: boolean;
  }>;
}

export default function CaseDetailPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [commentText, setCommentText] = useState("");
  
  const [match, params] = useRoute("/cases/:id");
  
  if (!match || !params?.id) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Case Not Found</h2>
            <p className="text-muted-foreground mb-4">The case you're looking for doesn't exist</p>
            <Button onClick={() => setLocation("/")} data-testid="button-back-home">
              Go Back Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const caseId = params.id;

  const { data: caseDetail, isLoading } = useQuery<CaseDetail>({
    queryKey: [`/api/cases/${caseId}`],
  });

  const voteMutation = useMutation({
    mutationFn: ({ pollOptionId }: { pollOptionId: string }) =>
      apiRequest("POST", `/api/cases/${caseId}/vote`, { pollOptionId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/cases/${caseId}`] });
      toast({
        title: "Vote Recorded",
        description: "Your vote has been successfully recorded.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Vote Failed",
        description: error.message || "Failed to record vote",
        variant: "destructive",
      });
    },
  });

  const commentMutation = useMutation({
    mutationFn: ({ content }: { content: string }) =>
      apiRequest("POST", `/api/cases/${caseId}/comments`, { content }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/cases/${caseId}`] });
      setCommentText("");
      toast({
        title: "Comment Posted",
        description: "Your comment has been successfully posted.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Comment Failed",
        description: error.message || "Failed to post comment",
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: ({ commentId }: { commentId: string }) =>
      apiRequest("POST", `/api/comments/${commentId}/like`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/cases/${caseId}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Like Failed",
        description: error.message || "Failed to like comment",
        variant: "destructive",
      });
    },
  });

  const handleVote = () => {
    if (!selectedOption) {
      toast({
        title: "No Option Selected",
        description: "Please select a poll option before voting",
        variant: "destructive",
      });
      return;
    }
    voteMutation.mutate({ pollOptionId: selectedOption });
  };

  const handleComment = () => {
    if (!commentText.trim()) {
      toast({
        title: "Empty Comment",
        description: "Please enter a comment before posting",
        variant: "destructive",
      });
      return;
    }
    commentMutation.mutate({ content: commentText.trim() });
  };

  const handleLike = (commentId: string) => {
    likeMutation.mutate({ commentId });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!caseDetail) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Case Not Found</h2>
            <p className="text-muted-foreground mb-4">The case you're looking for doesn't exist</p>
            <Button onClick={() => setLocation("/")} data-testid="button-back-home">
              Go Back Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const sortedOptions = [...caseDetail.pollOptions].sort((a, b) => a.orderIndex - b.orderIndex);
  const getVoteCount = (optionId: string) => {
    return caseDetail.voteCounts.find(vc => vc.pollOptionId === optionId)?.count || 0;
  };
  const totalVotes = caseDetail.voteCounts.reduce((sum, vc) => sum + vc.count, 0);
  const getVotePercentage = (optionId: string) => {
    if (totalVotes === 0) return 0;
    return Math.round((getVoteCount(optionId) / totalVotes) * 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Case Details */}
        <Card className="mb-6">
          <CardHeader>
            <div className="space-y-3">
              <CardTitle className="text-2xl">{caseDetail.title}</CardTitle>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  <span>{caseDetail.author?.fullName || caseDetail.author?.username || 'Anonymous'}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(caseDetail.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted/50 p-4 rounded-lg border border-primary/20">
              <h3 className="font-semibold text-primary mb-2" data-testid="text-question-label">Question:</h3>
              <p className="text-foreground" data-testid="text-question">{caseDetail.question}</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Case Description:</h3>
              <p className="text-foreground whitespace-pre-wrap">{caseDetail.description}</p>
            </div>
          </CardContent>
        </Card>

        {/* Poll Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Poll</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <RadioGroup
              value={caseDetail.userVote?.pollOptionId || selectedOption}
              onValueChange={setSelectedOption}
              disabled={!!caseDetail.userVote}
            >
              {sortedOptions.map((option) => {
                const voteCount = getVoteCount(option.id);
                const percentage = getVotePercentage(option.id);

                return (
                  <div
                    key={option.id}
                    className={`relative border rounded-lg p-4 hover:bg-accent/50 transition-colors ${
                      option.isAiGenerated ? 'bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900' : ''
                    }`}
                    data-testid={`poll-option-${option.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value={option.id} id={option.id} />
                      <Label 
                        htmlFor={option.id} 
                        className="flex-1 cursor-pointer font-normal"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            {option.isAiGenerated && (
                              <div className="flex items-center gap-1 mb-1">
                                <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                                <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">AI Suggested</span>
                              </div>
                            )}
                            <span className={option.isStandardOption ? "italic text-muted-foreground" : ""}>
                              {option.optionText}
                            </span>
                          </div>
                          {caseDetail.userVote && (
                            <Badge variant="secondary" className="ml-2">
                              {voteCount} ({percentage}%)
                            </Badge>
                          )}
                        </div>
                        {caseDetail.userVote && (
                          <div className="w-full bg-secondary rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${
                                option.isAiGenerated ? 'bg-blue-600 dark:bg-blue-500' : 'bg-primary'
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        )}
                      </Label>
                    </div>
                  </div>
                );
              })}
            </RadioGroup>

            {!caseDetail.userVote && (
              <Button
                onClick={handleVote}
                disabled={voteMutation.isPending || !selectedOption}
                className="w-full"
                data-testid="button-vote"
              >
                {voteMutation.isPending ? "Voting..." : "Submit Vote"}
              </Button>
            )}

            {caseDetail.userVote && (
              <div className="text-center text-sm text-muted-foreground">
                You have already voted. Total votes: {totalVotes}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comments Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Comments ({caseDetail.comments.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Add Comment */}
            <div className="space-y-3">
              <Textarea
                placeholder="Share your thoughts on this case..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                rows={3}
                data-testid="input-comment"
              />
              <Button
                onClick={handleComment}
                disabled={commentMutation.isPending}
                data-testid="button-post-comment"
              >
                {commentMutation.isPending ? "Posting..." : "Post Comment"}
              </Button>
            </div>

            {/* Comments List */}
            <div className="space-y-4 border-t pt-4">
              {caseDetail.comments.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No comments yet. Be the first to share your opinion!
                </p>
              ) : (
                caseDetail.comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="border rounded-lg p-4"
                    data-testid={`comment-${comment.id}`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-medium text-sm">
                          {comment.user?.fullName || comment.user?.username || 'Anonymous'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(comment.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <Button
                        variant={comment.userLiked ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleLike(comment.id)}
                        data-testid={`button-like-${comment.id}`}
                      >
                        <ThumbsUp className="w-4 h-4 mr-1" />
                        {comment.likeCount}
                      </Button>
                    </div>
                    <p className="text-foreground whitespace-pre-wrap">{comment.content}</p>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
