import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, Lock, Mail } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold text-foreground">Healthcare Provider Portal</h1>
          </div>
          <Button 
            onClick={handleLogin} 
            className="bg-primary hover:bg-primary/90"
            data-testid="button-login-header"
          >
            Sign In
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4">
            For Healthcare Professionals Only
          </Badge>
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Secure Healthcare Professional Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            A dedicated platform for verified healthcare providers to access 
            professional resources, collaborate, and share clinical insights.
          </p>
          <Button 
            size="lg" 
            onClick={handleLogin}
            className="bg-primary hover:bg-primary/90 text-lg px-8"
            data-testid="button-login-hero"
          >
            Access Provider Portal
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardHeader className="text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Verified Professionals</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center">
                Access restricted to licensed healthcare providers with verified credentials 
                and institutional affiliations.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Lock className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle>Secure Platform</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center">
                Enterprise-grade security with encrypted communications and 
                HIPAA-compliant data handling practices.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Professional Network</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center">
                Connect with fellow healthcare professionals and access 
                peer-reviewed clinical resources and discussions.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Important Notice */}
        <Card className="border-destructive/20 bg-destructive/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <Shield className="w-5 h-5" />
              Important Notice for Healthcare Providers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="text-sm">
                <strong>Professional Use Only:</strong> This application is exclusively designed 
                for licensed healthcare providers, including doctors, nurses, and equivalent 
                medical professionals.
              </p>
              <p className="text-sm">
                <strong>Patient Access Restricted:</strong> If you are a patient seeking medical 
                information or care, please do not use this platform. Instead, consult directly 
                with your healthcare provider.
              </p>
              <p className="text-sm">
                <strong>Clinical Judgment Required:</strong> All information exchanged on this 
                platform is supplementary and may be incomplete. Professional medical judgment 
                and adherence to current clinical guidelines are essential.
              </p>
              <p className="text-sm">
                <strong>Verification Process:</strong> All users must provide valid institutional 
                credentials and undergo verification before gaining platform access.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Registration Process */}
        <div className="mt-12 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            New to the Platform?
          </h2>
          <p className="text-muted-foreground mb-6">
            Join our network of verified healthcare professionals. 
            Registration requires institutional verification.
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Button 
              variant="outline" 
              onClick={handleLogin}
              data-testid="button-register"
            >
              <Mail className="w-4 h-4 mr-2" />
              Register as Healthcare Provider
            </Button>
            <Button 
              variant="ghost" 
              onClick={handleLogin}
              data-testid="button-forgot-password"
            >
              Forgot Password?
            </Button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>
              © 2024 Healthcare Provider Portal. For licensed healthcare professionals only.
            </p>
            <p className="mt-2">
              This platform complies with healthcare data protection regulations and 
              maintains strict access controls for professional use.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
