import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Plus, MessageSquare, BarChart3, User } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface CaseWithDetails {
  id: string;
  authorId: string;
  title: string;
  description: string;
  createdAt: string;
  author: {
    id: string;
    username: string;
    fullName: string;
  } | null;
  pollOptions: any[];
  voteCounts: { pollOptionId: string; count: number }[];
  mediaFiles: any[];
}

export default function Home() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  const { data: cases, isLoading: casesLoading } = useQuery<CaseWithDetails[]>({
    queryKey: ["/api/cases"],
    enabled: !!user,
  });

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      window.location.href = "/login";
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  if (authLoading || casesLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getTotalVotes = (caseItem: CaseWithDetails) => {
    return caseItem.voteCounts.reduce((sum, vc) => sum + vc.count, 0);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-foreground">P2Pconsult</h1>
            <p className="text-sm text-muted-foreground">Peer-to-peer medical consultation</p>
          </div>
          <div className="flex items-center gap-3">
            {user?.isAdmin && (
              <Button 
                variant="outline" 
                onClick={() => setLocation("/admin")}
                data-testid="button-admin"
              >
                <User className="w-4 h-4 mr-2" />
                Admin
              </Button>
            )}
            <Button 
              onClick={() => setLocation("/create-case")}
              data-testid="button-create-case"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Case
            </Button>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              data-testid="button-logout"
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-foreground mb-2">Medical Case Discussions</h2>
          <p className="text-muted-foreground">
            Browse cases from fellow doctors and share your medical opinions
          </p>
        </div>

        {!cases || cases.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground mb-4">No cases posted yet</p>
              <Button onClick={() => setLocation("/create-case")} data-testid="button-create-first-case">
                <Plus className="w-4 h-4 mr-2" />
                Create First Case
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {cases.map((caseItem) => (
              <Card 
                key={caseItem.id} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setLocation(`/cases/${caseItem.id}`)}
                data-testid={`case-card-${caseItem.id}`}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{caseItem.title}</CardTitle>
                      <CardDescription>
                        Posted by {caseItem.author?.fullName || caseItem.author?.username || 'Anonymous'} • {new Date(caseItem.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {caseItem.mediaFiles.length > 0 && (
                        <Badge variant="secondary">
                          {caseItem.mediaFiles.length} {caseItem.mediaFiles.length === 1 ? 'image' : 'images'}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground line-clamp-2 mb-4">
                    {caseItem.description}
                  </p>
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <BarChart3 className="w-4 h-4" />
                      <span>{caseItem.pollOptions.length} options</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>{getTotalVotes(caseItem)} votes</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
