import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  registrationSchema, 
  passwordResetSchema, 
  resendActivationSchema,
  type Registration,
  type PasswordReset,
  type ResendActivation 
} from "@shared/schema";
import { User, AlertTriangle, Mail, ShieldCheck } from "lucide-react";
import { z } from "zod";

type TabType = 'login' | 'register' | 'reset' | 'resend';

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Auth() {
  const [activeTab, setActiveTab] = useState<TabType>('login');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { toast } = useToast();

  // Login form
  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Registration form
  const registerForm = useForm<Registration>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      emailConfirm: "",
      isPracticingDoctor: false,
      yearsInPractice: 1,
      institute: "",
    },
  });

  // Password reset form
  const resetForm = useForm<PasswordReset>({
    resolver: zodResolver(passwordResetSchema),
    defaultValues: {
      email: "",
    },
  });

  // Resend activation form
  const resendForm = useForm<ResendActivation>({
    resolver: zodResolver(resendActivationSchema),
    defaultValues: {
      email: "",
    },
  });

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleRegister = async (data: Registration) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/auth/register", data);
      setShowSuccess(true);
      registerForm.reset();
      toast({
        title: "Registration Successful",
        description: "Please check your email for activation instructions.",
      });
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to register. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordReset = async (data: PasswordReset) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/auth/password-reset", data);
      setShowSuccess(true);
      resetForm.reset();
      toast({
        title: "Reset Link Sent",
        description: "If an account exists, you will receive a password reset email.",
      });
    } catch (error: any) {
      toast({
        title: "Request Failed",
        description: error.message || "Failed to send reset email.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendActivation = async (data: ResendActivation) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/auth/resend-activation", data);
      setShowSuccess(true);
      resendForm.reset();
      toast({
        title: "Activation Email Sent",
        description: "If your account needs activation, you will receive an email.",
      });
    } catch (error: any) {
      toast({
        title: "Request Failed",
        description: error.message || "Failed to send activation email.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const tabs = [
    { id: 'login', label: 'Login' },
    { id: 'register', label: 'Register' },
    { id: 'reset', label: 'Reset Password' },
    { id: 'resend', label: 'Resend Activation' },
  ] as const;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardContent className="p-8">
          {/* Header with Icon */}
          <div className="flex justify-center mb-6">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <User className="w-7 h-7 text-primary-foreground" />
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b mb-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setShowSuccess(false);
                }}
                className={`flex-1 py-3 px-1 text-center text-sm font-medium transition-colors border-b-2 ${
                  activeTab === tab.id
                    ? 'text-primary border-primary'
                    : 'text-muted-foreground border-transparent hover:text-primary'
                }`}
                data-testid={`tab-${tab.id}`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Login Section */}
          {activeTab === 'login' && (
            <div>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">Login</h1>
                <p className="text-sm text-muted-foreground">
                  Welcome back! Please enter your credentials.
                </p>
              </div>

              <Alert className="mb-6 border-destructive/20 bg-destructive/5">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <AlertDescription className="text-destructive">
                  <strong>Important Notice:</strong> This application is only for healthcare 
                  providers such as doctors. If you are a patient, please do not use this 
                  because the information exchange here is only partial and limited, therefore 
                  can be misleading without additional professional judgement.
                </AlertDescription>
              </Alert>

              <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <div>
                  <Label htmlFor="login-username">Username</Label>
                  <Input
                    id="login-username"
                    {...loginForm.register("username")}
                    placeholder="Enter your username"
                    data-testid="input-username"
                  />
                  {loginForm.formState.errors.username && (
                    <p className="text-sm text-destructive mt-1">
                      {loginForm.formState.errors.username.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    {...loginForm.register("password")}
                    placeholder="Enter your password"
                    data-testid="input-password"
                  />
                  {loginForm.formState.errors.password && (
                    <p className="text-sm text-destructive mt-1">
                      {loginForm.formState.errors.password.message}
                    </p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  data-testid="button-signin"
                >
                  Sign In
                </Button>

                <div className="text-center space-y-2 pt-4">
                  <div className="flex justify-center gap-2 flex-wrap text-sm">
                    <button
                      type="button"
                      onClick={() => setActiveTab('register')}
                      className="text-primary hover:underline"
                      data-testid="link-create-account"
                    >
                      Create an account
                    </button>
                    <span className="text-muted-foreground">•</span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('reset')}
                      className="text-primary hover:underline"
                      data-testid="link-forgot-password"
                    >
                      Forgot password?
                    </button>
                    <span className="text-muted-foreground">•</span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('resend')}
                      className="text-primary hover:underline"
                      data-testid="link-resend-activation"
                    >
                      Resend activation
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {/* Register Section */}
          {activeTab === 'register' && (
            <div>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">Register</h1>
                <p className="text-sm text-muted-foreground">
                  Create your healthcare provider account.
                </p>
              </div>

              <Alert className="mb-6 border-secondary/20 bg-secondary/5">
                <ShieldCheck className="h-4 w-4 text-secondary" />
                <AlertDescription>
                  <em>The information exchanged here is only partial and limited, therefore 
                  can be misleading or erroneous without your own professional judgements. 
                  Please use this website with utmost caution.</em>
                </AlertDescription>
              </Alert>

              {showSuccess ? (
                <Alert className="mb-6 border-primary/20 bg-primary/5">
                  <Mail className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-primary">
                    <strong>Registration Successful!</strong> Please check your email for 
                    activation instructions. You may need to check your spam folder.
                  </AlertDescription>
                </Alert>
              ) : (
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <div>
                    <Label htmlFor="register-username">
                      Username <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="register-username"
                      {...registerForm.register("username")}
                      placeholder="Choose a username"
                      data-testid="input-register-username"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.
                    </p>
                    {registerForm.formState.errors.username && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.username.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="register-password">
                      Password <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="register-password"
                      type="password"
                      {...registerForm.register("password")}
                      placeholder="Create a strong password"
                      data-testid="input-register-password"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Use a combination of letters, numbers, and special characters.
                    </p>
                    {registerForm.formState.errors.password && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.password.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="register-email">
                      Email (please use work email for verification) <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="register-email"
                      type="email"
                      {...registerForm.register("email")}
                      placeholder="your.name@hospital.com"
                      data-testid="input-register-email"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      You can change it later after verification.
                    </p>
                    {registerForm.formState.errors.email && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.email.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="register-email-confirm">
                      Re-enter Work Email <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="register-email-confirm"
                      type="email"
                      {...registerForm.register("emailConfirm")}
                      placeholder="Confirm your email address"
                      data-testid="input-register-email-confirm"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Enter the same email as above, for verification.
                    </p>
                    {registerForm.formState.errors.emailConfirm && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.emailConfirm.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>
                      Are you a practicing doctor or equivalent? <span className="text-destructive">*</span>
                    </Label>
                    <RadioGroup
                      onValueChange={(value) => 
                        registerForm.setValue("isPracticingDoctor", value === "yes")
                      }
                      className="mt-2"
                      data-testid="radio-practicing-doctor"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="doctor-no" />
                        <Label htmlFor="doctor-no">No</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="yes" id="doctor-yes" />
                        <Label htmlFor="doctor-yes">Yes</Label>
                      </div>
                    </RadioGroup>
                    {registerForm.formState.errors.isPracticingDoctor && (
                      <p className="text-sm text-destructive mt-1">
                        Please select an option
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="years-practice">
                      Years in practice (exclude all types of training) <span className="text-destructive">*</span>
                    </Label>
                    <Select
                      onValueChange={(value) => 
                        registerForm.setValue("yearsInPractice", parseInt(value))
                      }
                    >
                      <SelectTrigger data-testid="select-years-practice">
                        <SelectValue placeholder="Select years..." />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 20 }, (_, i) => i + 1).map((year) => (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        ))}
                        <SelectItem value="21">20 or above</SelectItem>
                      </SelectContent>
                    </Select>
                    {registerForm.formState.errors.yearsInPractice && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.yearsInPractice.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="institute">
                      Institute (for verification purpose only) <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="institute"
                      {...registerForm.register("institute")}
                      placeholder="Hospital or medical institution name"
                      data-testid="input-institute"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      We use this only to verify your credentials.
                    </p>
                    {registerForm.formState.errors.institute && (
                      <p className="text-sm text-destructive mt-1">
                        {registerForm.formState.errors.institute.message}
                      </p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                    data-testid="button-create-account"
                  >
                    {isSubmitting ? "Creating Account..." : "Create Account"}
                  </Button>

                  <div className="text-center pt-4">
                    <span className="text-sm text-muted-foreground">Already have an account? </span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('login')}
                      className="text-sm text-primary hover:underline"
                      data-testid="link-signin"
                    >
                      Sign in
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Reset Password Section */}
          {activeTab === 'reset' && (
            <div>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">Reset Password</h1>
                <p className="text-sm text-muted-foreground">
                  Enter your email address and we'll send you a link to reset your password.
                </p>
              </div>

              <Alert className="mb-6 border-primary/20 bg-primary/5">
                <Mail className="h-4 w-4 text-primary" />
                <AlertDescription>
                  <strong>📧 Email Verification Required:</strong> We will send a password reset 
                  link to your registered email address. Please check your inbox and spam folder.
                </AlertDescription>
              </Alert>

              {showSuccess ? (
                <Alert className="mb-6 border-primary/20 bg-primary/5">
                  <Mail className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-primary">
                    <strong>✅ Email Sent!</strong> If an account exists with this email, 
                    you will receive a password reset link shortly. Please check your inbox and spam folder.
                  </AlertDescription>
                </Alert>
              ) : (
                <form onSubmit={resetForm.handleSubmit(handlePasswordReset)} className="space-y-4">
                  <div>
                    <Label htmlFor="reset-email">Email Address</Label>
                    <Input
                      id="reset-email"
                      type="email"
                      {...resetForm.register("email")}
                      placeholder="Enter your registered email"
                      data-testid="input-reset-email"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Enter the email address associated with your account.
                    </p>
                    {resetForm.formState.errors.email && (
                      <p className="text-sm text-destructive mt-1">
                        {resetForm.formState.errors.email.message}
                      </p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                    data-testid="button-send-reset"
                  >
                    {isSubmitting ? "Sending..." : "Send Reset Link"}
                  </Button>

                  <div className="text-center pt-4">
                    <button
                      type="button"
                      onClick={() => setActiveTab('login')}
                      className="text-sm text-primary hover:underline"
                      data-testid="link-back-login"
                    >
                      ← Back to login
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Resend Activation Section */}
          {activeTab === 'resend' && (
            <div>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">Resend Activation Email</h1>
                <p className="text-sm text-muted-foreground">
                  Didn't receive the activation email? We can send it again.
                </p>
              </div>

              <Alert className="mb-6 border-primary/20 bg-primary/5">
                <Mail className="h-4 w-4 text-primary" />
                <AlertDescription>
                  <strong>📧 Account Activation:</strong> Enter the email address you used during 
                  registration. We'll send a new activation link to help you complete your account setup.
                </AlertDescription>
              </Alert>

              {showSuccess ? (
                <Alert className="mb-6 border-primary/20 bg-primary/5">
                  <Mail className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-primary">
                    <strong>✅ Email Sent!</strong> If your account needs activation, 
                    you will receive a new activation link shortly. Please check your inbox and spam folder.
                  </AlertDescription>
                </Alert>
              ) : (
                <form onSubmit={resendForm.handleSubmit(handleResendActivation)} className="space-y-4">
                  <div>
                    <Label htmlFor="resend-email">Email Address</Label>
                    <Input
                      id="resend-email"
                      type="email"
                      {...resendForm.register("email")}
                      placeholder="Enter your registration email"
                      data-testid="input-resend-email"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Enter the email you used when registering.
                    </p>
                    {resendForm.formState.errors.email && (
                      <p className="text-sm text-destructive mt-1">
                        {resendForm.formState.errors.email.message}
                      </p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                    data-testid="button-resend-activation"
                  >
                    {isSubmitting ? "Sending..." : "Resend Activation Email"}
                  </Button>

                  <div className="text-center pt-4">
                    <button
                      type="button"
                      onClick={() => setActiveTab('login')}
                      className="text-sm text-primary hover:underline"
                      data-testid="link-back-login-resend"
                    >
                      ← Back to login
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
