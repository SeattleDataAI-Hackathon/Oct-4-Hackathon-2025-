import {
  users,
  cases,
  mediaFiles,
  pollOptions,
  votes,
  comments,
  commentLikes,
  type User,
  type InsertUser,
  type Case,
  type InsertCase,
  type MediaFile,
  type InsertMediaFile,
  type PollOption,
  type InsertPollOption,
  type Vote,
  type InsertVote,
  type Comment,
  type InsertComment,
  type CommentLike,
  type InsertCommentLike,
  type Registration,
  type UpdateUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(userData: Registration & { hashedPassword: string }): Promise<User>;
  updateUser(id: string, userData: UpdateUser): Promise<User | undefined>;
  deleteUser(id: string): Promise<void>;
  getAllUsers(): Promise<User[]>;
  
  // Case operations
  getCase(id: string): Promise<Case | undefined>;
  getAllCases(): Promise<Case[]>;
  createCase(caseData: InsertCase): Promise<Case>;
  deleteCase(id: string): Promise<void>;
  
  // Media operations
  createMediaFile(mediaData: InsertMediaFile): Promise<MediaFile>;
  getMediaFilesByCase(caseId: string): Promise<MediaFile[]>;
  
  // Poll operations
  createPollOption(pollData: InsertPollOption): Promise<PollOption>;
  getPollOptionsByCase(caseId: string): Promise<PollOption[]>;
  
  // Vote operations
  createVote(voteData: InsertVote): Promise<Vote>;
  getUserVoteForCase(userId: string, caseId: string): Promise<Vote | undefined>;
  getVoteCountsForCase(caseId: string): Promise<{ pollOptionId: string; count: number }[]>;
  
  // Comment operations
  createComment(commentData: InsertComment): Promise<Comment>;
  getCommentsByCase(caseId: string): Promise<Comment[]>;
  deleteComment(id: string): Promise<void>;
  
  // Comment like operations
  toggleCommentLike(commentId: string, userId: string): Promise<void>;
  getCommentLikeCount(commentId: string): Promise<number>;
  hasUserLikedComment(commentId: string, userId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: Registration & { hashedPassword: string }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: userData.username,
        password: userData.hashedPassword,
        email: userData.email,
        fullName: userData.fullName,
        institute: userData.institute,
        isAdmin: false,
      })
      .returning();
    return user;
  }

  async updateUser(id: string, userData: UpdateUser): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Case operations
  async getCase(id: string): Promise<Case | undefined> {
    const [caseRecord] = await db.select().from(cases).where(eq(cases.id, id));
    return caseRecord;
  }

  async getAllCases(): Promise<Case[]> {
    return await db.select().from(cases).orderBy(desc(cases.createdAt));
  }

  async createCase(caseData: InsertCase): Promise<Case> {
    const [caseRecord] = await db.insert(cases).values(caseData).returning();
    return caseRecord;
  }

  async deleteCase(id: string): Promise<void> {
    await db.delete(cases).where(eq(cases.id, id));
  }

  // Media operations
  async createMediaFile(mediaData: InsertMediaFile): Promise<MediaFile> {
    const [media] = await db.insert(mediaFiles).values(mediaData).returning();
    return media;
  }

  async getMediaFilesByCase(caseId: string): Promise<MediaFile[]> {
    return await db.select().from(mediaFiles).where(eq(mediaFiles.caseId, caseId));
  }

  // Poll operations
  async createPollOption(pollData: InsertPollOption): Promise<PollOption> {
    const [option] = await db.insert(pollOptions).values(pollData).returning();
    return option;
  }

  async getPollOptionsByCase(caseId: string): Promise<PollOption[]> {
    return await db
      .select()
      .from(pollOptions)
      .where(eq(pollOptions.caseId, caseId))
      .orderBy(pollOptions.orderIndex);
  }

  // Vote operations
  async createVote(voteData: InsertVote): Promise<Vote> {
    const [vote] = await db.insert(votes).values(voteData).returning();
    return vote;
  }

  async getUserVoteForCase(userId: string, caseId: string): Promise<Vote | undefined> {
    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.userId, userId), eq(votes.caseId, caseId)));
    return vote;
  }

  async getVoteCountsForCase(caseId: string): Promise<{ pollOptionId: string; count: number }[]> {
    const results = await db
      .select({
        pollOptionId: votes.pollOptionId,
        count: sql<number>`count(*)::int`,
      })
      .from(votes)
      .where(eq(votes.caseId, caseId))
      .groupBy(votes.pollOptionId);
    return results;
  }

  // Comment operations
  async createComment(commentData: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(commentData).returning();
    return comment;
  }

  async getCommentsByCase(caseId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.caseId, caseId))
      .orderBy(comments.createdAt);
  }

  async deleteComment(id: string): Promise<void> {
    await db.delete(comments).where(eq(comments.id, id));
  }

  // Comment like operations
  async toggleCommentLike(commentId: string, userId: string): Promise<void> {
    const [existing] = await db
      .select()
      .from(commentLikes)
      .where(and(eq(commentLikes.commentId, commentId), eq(commentLikes.userId, userId)));

    if (existing) {
      await db
        .delete(commentLikes)
        .where(and(eq(commentLikes.commentId, commentId), eq(commentLikes.userId, userId)));
    } else {
      await db.insert(commentLikes).values({ commentId, userId });
    }
  }

  async getCommentLikeCount(commentId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(commentLikes)
      .where(eq(commentLikes.commentId, commentId));
    return result?.count || 0;
  }

  async hasUserLikedComment(commentId: string, userId: string): Promise<boolean> {
    const [like] = await db
      .select()
      .from(commentLikes)
      .where(and(eq(commentLikes.commentId, commentId), eq(commentLikes.userId, userId)));
    return !!like;
  }
}

export const storage = new DatabaseStorage();
