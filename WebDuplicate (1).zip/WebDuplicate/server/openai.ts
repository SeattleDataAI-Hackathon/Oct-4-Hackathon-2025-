import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateMedicalCaseAnswer(
  caseTitle: string,
  question: string,
  description: string
): Promise<string> {
  const prompt = `You are a medical expert assistant. Given the following medical case, provide a concise, professional answer to the question.

Case Title: ${caseTitle}

Question: ${question}

Case Description:
${description}

Provide a brief, evidence-based answer (2-3 sentences maximum) that addresses the question directly. Be professional and clear.`;

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      {
        role: "system",
        content: "You are a medical expert who provides concise, evidence-based answers to clinical questions. Keep answers brief and professional."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    max_completion_tokens: 200,
  });

  const content = response.choices[0].message.content?.trim();
  
  if (!content || content.length === 0) {
    throw new Error("OpenAI returned empty response");
  }

  return content;
}
